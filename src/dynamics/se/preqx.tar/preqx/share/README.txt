This directory contains code using the mimetic finite difference method described in Simmons and Burridge 1981.

